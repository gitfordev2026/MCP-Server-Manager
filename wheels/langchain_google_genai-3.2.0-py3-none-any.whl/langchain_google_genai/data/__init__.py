"""Model profile data. All edits should be made in profile_augmentations.toml."""
