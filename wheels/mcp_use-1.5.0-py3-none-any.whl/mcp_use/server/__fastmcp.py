"""FastMCP mirror for easy migrations."""

from mcp_use.server import MCPServer as FastMCP

__all__ = ["FastMCP"]
