"""Middleware for MCP agents."""

from mcp_use.agents.middleware.tool_error_middleware import tool_error_handler

__all__ = ["tool_error_handler"]
